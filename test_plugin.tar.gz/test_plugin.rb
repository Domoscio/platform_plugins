module TestPlugin

    def self.extended(router)
        router.instance_exec do
            namespace :test_plugin do
                get 'view', to: 'view#show', as: 'view'
            end
        end
    end
end