module TestPlugin
    class ViewController < ApplicationController
        before_action :prepend_view_paths

        def show
            render
        end

        def prepend_view_paths
            prepend_view_path "app/plugins/test_plugin/app/views"
        end

    end
end