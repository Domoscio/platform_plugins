class TestPlugin::InstallGenerator < ::Rails::Generators::Base
    include Rails::Generators::Migration
    source_root File.expand_path('../templates', __FILE__)
    desc 'Installs TestPlugin'

    def install

        inject_into_file 'config/routes.rb', after: "#plugins" do <<-'RUBY'
            
        extend TestPlugin
        RUBY
        end
    end
end