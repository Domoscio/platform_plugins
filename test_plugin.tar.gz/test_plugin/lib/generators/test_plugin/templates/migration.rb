class TestPluginCreateTables < ActiveRecord::Migration[5.1]
    def change
        create_table :test_plugin_table do |t|
            t.string :title
        end

    end
end